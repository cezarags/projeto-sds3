package br.com.devjunior.djvendas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DjvendasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DjvendasApplication.class, args);
	}

}
